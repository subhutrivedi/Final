import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.css']
})
export class EmployeeDashboardComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private router: Router) { 
    
  }

  ngOnInit() {
  }

  handleUpload(){
    this.router.navigate(['/upload']);
  }

}
