import { Component, OnInit } from '@angular/core';
import { Message } from '../message';
import { HelloWordService } from '../hello-word.service';
import { HttpClient, HttpEventType } from '@angular/common/http';
//import { FormBuilder, FormGroup } from '@angular/forms';
//import { HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-hello-world',
  templateUrl: './hello-world.component.html',
  styleUrls: ['./hello-world.component.css']
})

export class HelloWorldComponent implements OnInit {

  message1: string;

  constructor(private helloWorldService: HelloWordService, private httpClient: HttpClient) { }
  selectedFile: File;
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  message: string;
  imageName: any;

  ngOnInit() {
    console.log("HelloWorldComponent");
    this.helloWorldService.helloWorldService().subscribe( (result) => {
      this.message1 = result.content;
    });
  }

   //Gets called when the user selects an image
  public onFileChanged(event) {
   this.selectedFile = event.target.files[0];
  }

  //Gets called when the user clicks on submit to upload the image
  onUpload() {
    console.log(this.selectedFile);
    //FormData API provides methods and properties to allow us easily prepare form data to be sent with POST HTTP requests.
    const uploadImageData = new FormData();
    
    uploadImageData.append('file', this.selectedFile, this.selectedFile.name);
   // uploadImageData.append('file', this.selectedFile, this.selectedFile.name);
    console.log(uploadImageData.get('file'));
    //Make a call to the Spring Boot Application to save the image
    this.httpClient.post('http://localhost:8080/api/v1/uploadFile', uploadImageData, {
      headers: {'Content-Type': 'multipart/form-data'}
    })
      .subscribe((response) => {
        console.log(response);
      }
    );
  }

      //Gets called when the user clicks on retieve image button to get the image from back end
    getImage() {
    //Make a call to Sprinf Boot to get the Image Bytes.
    this.httpClient.get('http://localhost:8080/image/get/' + this.imageName)
    .subscribe(
        res => {
          this.retrieveResonse = res;
          this.base64Data = this.retrieveResonse.picByte;
          this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
        }
      );
    }
}
