import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Document} from '../document'
import { from } from 'rxjs';

@Component({
  selector: 'app-view-documents',
  templateUrl: './view-documents.component.html',
  styleUrls: ['./view-documents.component.css']
})
export class ViewDocumentsComponent implements OnInit {

  emp_id: string;
  document: Document;

  constructor(private route: ActivatedRoute,private router: Router,
    private employeeService: EmployeeService) { }

  ngOnInit() {
    this.document = new Document();

    this.emp_id = this.route.snapshot.params['emp_id'];
    
    this.employeeService.getEmployee(this.emp_id)
      .subscribe(data => {
        console.log(data)
        this.document = data;
      }, error => console.log(error));
  }

}
