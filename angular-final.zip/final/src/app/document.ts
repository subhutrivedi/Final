export class Document {
    emp_id: string;
    doc: string;
    active: boolean;
}