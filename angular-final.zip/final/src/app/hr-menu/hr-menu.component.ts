import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hr-menu',
  templateUrl: './hr-menu.component.html',
  styleUrls: ['./hr-menu.component.css']
})
export class HrMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
